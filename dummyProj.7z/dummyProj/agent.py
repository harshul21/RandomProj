from google.adk.agents import Agent
from google.adk.tools.agent_tool import AgentTool
from google.adk.agents import SequentialAgent, ParallelAgent, LlmAgent

GEMINI_MODEL = "gemini-2.0-flash"  # Replace with the actual model name you want to use

LOG_DATA_INSTRUCTION = """
You are a log tag analyzer. Analyze the user's problem description and return relevant log tag names with their issue sources.

Instructions:
- Use ONLY the predefined logtags listed below
- If the user explicitly mentions a model (LFD or Hotel TV), use it
- If model is not mentioned, infer: CMS = LFD, Hotel = Hotel TV, etc.
- Analyze the user's scenario against the predefined scenarios
- Return the relevant tag names and their corresponding issue sources

Predefined Logtags:
[
  {
    "tag": "CMS_HEARTBEAT_MISS",
    "issue_source": "CMS",
    "description": "CMS server isn't receiving heartbeat.",
    "relevant_models": ["LFD"],
    "scenarios": ["CMS dashboard shows screen as offline."]
  },
  {
    "tag": "AUTH_FAILURE",
    "issue_source": "NETWORK",
    "description": "Login or token failure.",
    "relevant_models": ["Hotel TV"],
    "scenarios": ["Login screen keeps reappearing."]
  }
]

Output: Return the tag names and issue sources as: tag_name:issue_source, one per line. If no tags match, return "":"".
Example: CMS_HEARTBEAT_MISS:CMS
"""

DIAGNOSTIC_DATA_INSTRUCTION = """
You are a diagnostic tag analyzer. Analyze the user's problem description and return relevant diagnostic task objects.

Instructions:
- Use ONLY the predefined diagnostic tags listed below
- If the user explicitly mentions a model (LFD or Hotel TV), use it
- If model is not mentioned, infer: CMS = LFD, Hotel = Hotel TV, etc.
- Analyze the user's scenario against the predefined scenarios
- Always include diagnostic tag with taskname "validationui"
- Return the complete JSON objects for relevant tags (exclude description and scenarios fields)

Predefined Diagnostic Tags:
[
    {
        "taskID": 1,
        "taskName":"PING_TEST",
        "taskCategory":"MEMORY",
        "taskInterval": 5,
        "taskCommand": "free",
        "taskFileName": "free",
        "description": "When issue with network connectivity",
        "scenarios": ["Problem in scheduling content", "Device offline"]
    },
    {
        "taskID": 1,
        "taskName":"TOKEN_VALIDATION",
        "taskCategory":"MEMORY",
        "taskInterval": 5,
        "taskCommand": "free",
        "taskFileName": "free",
        "description": "When issue with network connectivity",
        "scenarios": ["Problem in scheduling content", "Device offline"]
    },
    {
        "taskID": 1,
        "taskName":"validationui",
        "taskCategory":"MEMORY",
        "taskInterval": 0,
        "taskCommand": 7985,
        "taskFileName": "free",
        "description": "When issue with network connectivity",
        "scenarios": ["Problem in scheduling content", "Device offline"]
    }
]

Output: Return the JSON objects as an array (without description and scenarios fields). Always include validationui task.
"""

COMBINE_DATA_INSTRUCTION = """
You are combining results from two agents into a final JSON response.

Input Data:
- Log Tags Result: {log_tags_results}
- Diagnostic Tags Result: {diagnostic_tags_results}

Task: Create a JSON response with the following structure:

{{[array of log tag names];{
    "Name": "logfile_5465",
    "Product": "LFD",
    "ValidationCode": "7989",
    "diagnostic_tags": [array of diagnostic JSON objects],
    "rebootDevice": "no",
    "debugFilter": "",
    "clearLogs": "no",
    "log_tags": [array of log tag names],
    "issue_source": "",
    "is_legacy": "no",
    "HYPERUART": "no",
    "flag": "no",
    "url": "",
    "domain": "",
    "username": "",
    "password": ""
}}

Instructions:
1. Parse the log_tags_results which contains tag_name:issue_source pairs
2. Extract tag names for the log_tags array
3. Extract issue sources and combine them with commas for the issue_source field
4. Parse the diagnostic_tags_results and put the JSON objects in the diagnostic_tags array
5. If any input is empty, use appropriate defaults (empty arrays or empty strings)
6. Return ONLY the final JSON structure
7. Do not include any explanatory text or formatting.
8. ALWAYS include the list of log tag names in the beginning of the JSON as shown in the structure above.

Your response must be valid JSON starting with {{ and ending with }}.
"""

log_data_tag_generation_agent = LlmAgent(
    name="LogDataTagGeneration",
    model=GEMINI_MODEL,
    instruction=LOG_DATA_INSTRUCTION,
    output_key="log_tags_results",
)

diagnostic_data_tag_generation_agent = LlmAgent(
    name="DiagnosticDataTagGeneration",
    model=GEMINI_MODEL,
    instruction=DIAGNOSTIC_DATA_INSTRUCTION,
    output_key="diagnostic_tags_results",
)

parallel_tag_generation_agent = SequentialAgent(
    name="ParallelTagGeneration",
    sub_agents=[log_data_tag_generation_agent, diagnostic_data_tag_generation_agent],
    description="Generate log tags in sequence for log data and diagnostic data.",
)

combine_agent = LlmAgent(
    name="CombineResults",
    model=GEMINI_MODEL,
    instruction=COMBINE_DATA_INSTRUCTION,
    output_key="combined_results",
)

sequential_pipeline_agent = SequentialAgent(
    name="AnalyseAndGeneratePipeline",
    sub_agents=[parallel_tag_generation_agent, combine_agent],
    description="Coordinated parallel log data tag generation and diagnostic data tag generation. Synthesize the combined results.",
)

root_agent = sequential_pipeline_agent